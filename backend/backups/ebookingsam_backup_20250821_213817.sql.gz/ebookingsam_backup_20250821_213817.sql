--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_gallery_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_gallery_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_gallery_updated_at() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.addons (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    price numeric(10,2) NOT NULL,
    description text
);


ALTER TABLE public.addons OWNER TO postgres;

--
-- Name: addons_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.addons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.addons_id_seq OWNER TO postgres;

--
-- Name: addons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.addons_id_seq OWNED BY public.addons.id;


--
-- Name: analytics_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_events (
    id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    user_id integer,
    session_id character varying(255),
    page_url text,
    referrer text,
    user_agent text,
    ip_address inet,
    country character varying(100),
    city character varying(100),
    device_type character varying(50),
    browser character varying(50),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.analytics_events OWNER TO postgres;

--
-- Name: TABLE analytics_events; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.analytics_events IS 'User behavior and system events tracking';


--
-- Name: COLUMN analytics_events.metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.analytics_events.metadata IS 'Flexible JSON storage for event-specific data';


--
-- Name: analytics_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_events_id_seq OWNER TO postgres;

--
-- Name: analytics_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_events_id_seq OWNED BY public.analytics_events.id;


--
-- Name: article_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.article_categories (
    article_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.article_categories OWNER TO postgres;

--
-- Name: article_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.article_tags (
    article_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.article_tags OWNER TO postgres;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    content text,
    excerpt character varying(500),
    main_image_url character varying(255),
    author_id integer,
    status character varying(20) DEFAULT 'published'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.articles OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_id_seq OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    admin_user_id integer,
    action character varying(50) NOT NULL,
    target_entity character varying(50) NOT NULL,
    entity_id integer,
    details jsonb,
    ip_address inet,
    user_agent text,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_action CHECK (((action)::text = ANY ((ARRAY['CREATE'::character varying, 'UPDATE'::character varying, 'DELETE'::character varying, 'APPROVE'::character varying, 'REJECT'::character varying, 'TOGGLE_STATUS'::character varying, 'LINK'::character varying, 'UNLINK'::character varying, 'LOGIN'::character varying, 'LOGOUT'::character varying])::text[]))),
    CONSTRAINT chk_target_entity CHECK (((target_entity)::text = ANY ((ARRAY['Tour'::character varying, 'User'::character varying, 'Vehicle'::character varying, 'AddOn'::character varying, 'PackageTier'::character varying, 'Review'::character varying, 'PasswordReset'::character varying, 'TourAddOn'::character varying, 'Booking'::character varying])::text[])))
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: TABLE audit_logs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.audit_logs IS 'Audit trail for all administrative actions';


--
-- Name: COLUMN audit_logs.admin_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_logs.admin_user_id IS 'ID of the admin who performed the action';


--
-- Name: COLUMN audit_logs.action; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_logs.action IS 'Type of action performed';


--
-- Name: COLUMN audit_logs.target_entity; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_logs.target_entity IS 'Type of entity that was affected';


--
-- Name: COLUMN audit_logs.entity_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_logs.entity_id IS 'ID of the specific entity affected';


--
-- Name: COLUMN audit_logs.details; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_logs.details IS 'JSON object with additional details about the action';


--
-- Name: COLUMN audit_logs.ip_address; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_logs.ip_address IS 'IP address from which the action was performed';


--
-- Name: COLUMN audit_logs.user_agent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_logs.user_agent IS 'Browser user agent string';


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: auditlogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auditlogs (
    id integer NOT NULL,
    admin_user_id integer NOT NULL,
    action_type character varying(50) NOT NULL,
    target_entity character varying(50) NOT NULL,
    target_id integer,
    details jsonb,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auditlogs OWNER TO postgres;

--
-- Name: auditlogs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auditlogs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auditlogs_id_seq OWNER TO postgres;

--
-- Name: auditlogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auditlogs_id_seq OWNED BY public.auditlogs.id;


--
-- Name: blog_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.blog_categories OWNER TO postgres;

--
-- Name: TABLE blog_categories; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.blog_categories IS 'Categories for organizing blog posts';


--
-- Name: blog_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_categories_id_seq OWNER TO postgres;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_categories_id_seq OWNED BY public.blog_categories.id;


--
-- Name: blog_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_comments (
    id integer NOT NULL,
    article_id integer NOT NULL,
    user_id integer NOT NULL,
    parent_comment_id integer,
    content text NOT NULL,
    is_approved boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.blog_comments OWNER TO postgres;

--
-- Name: blog_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_comments_id_seq OWNER TO postgres;

--
-- Name: blog_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_comments_id_seq OWNED BY public.blog_comments.id;


--
-- Name: blog_post_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_post_categories (
    blog_post_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.blog_post_categories OWNER TO postgres;

--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_posts (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    content text NOT NULL,
    excerpt text,
    featured_image_url text,
    author_id integer,
    status character varying(20) DEFAULT 'draft'::character varying,
    tags text[],
    meta_title character varying(255),
    meta_description text,
    read_time integer,
    view_count integer DEFAULT 0,
    is_featured boolean DEFAULT false,
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT blog_posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE public.blog_posts OWNER TO postgres;

--
-- Name: TABLE blog_posts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.blog_posts IS 'Blog posts for content marketing and SEO';


--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_posts_id_seq OWNER TO postgres;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_posts_id_seq OWNED BY public.blog_posts.id;


--
-- Name: blog_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_tags (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.blog_tags OWNER TO postgres;

--
-- Name: blog_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_tags_id_seq OWNER TO postgres;

--
-- Name: blog_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_tags_id_seq OWNED BY public.blog_tags.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    tour_id integer NOT NULL,
    package_tier_id integer NOT NULL,
    travel_date date NOT NULL,
    number_of_persons integer NOT NULL,
    additional_vehicles jsonb,
    selected_addons jsonb,
    status character varying(50) DEFAULT 'Inquiry Pending'::character varying NOT NULL,
    payment_timestamp timestamp with time zone,
    total_price numeric(12,2),
    selected_currency character varying(3) DEFAULT 'INR'::character varying,
    inquiry_date timestamp with time zone DEFAULT now(),
    customer_notes text,
    admin_notes text,
    cancellation_reason text,
    cancelled_at timestamp without time zone,
    confirmed_at timestamp without time zone
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bookings_id_seq OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: contact_inquiries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_inquiries (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(20),
    subject character varying(255),
    message text NOT NULL,
    inquiry_type character varying(50) DEFAULT 'general'::character varying,
    status character varying(20) DEFAULT 'new'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    assigned_to integer,
    response_sent boolean DEFAULT false,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT contact_inquiries_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT contact_inquiries_status_check CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'in_progress'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


ALTER TABLE public.contact_inquiries OWNER TO postgres;

--
-- Name: TABLE contact_inquiries; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.contact_inquiries IS 'Customer contact form submissions and inquiries';


--
-- Name: contact_inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_inquiries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contact_inquiries_id_seq OWNER TO postgres;

--
-- Name: contact_inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_inquiries_id_seq OWNED BY public.contact_inquiries.id;


--
-- Name: dashboard_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_metrics (
    id integer NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_value numeric(15,2),
    metric_date date NOT NULL,
    period_type character varying(20) NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dashboard_metrics OWNER TO postgres;

--
-- Name: TABLE dashboard_metrics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.dashboard_metrics IS 'Aggregated metrics for admin dashboard';


--
-- Name: dashboard_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dashboard_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dashboard_metrics_id_seq OWNER TO postgres;

--
-- Name: dashboard_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dashboard_metrics_id_seq OWNED BY public.dashboard_metrics.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    user_id integer NOT NULL,
    tour_id integer NOT NULL,
    rating integer NOT NULL,
    review_text text,
    is_approved boolean DEFAULT false,
    submission_date timestamp with time zone DEFAULT now(),
    helpful_count integer DEFAULT 0,
    images text[],
    verified_purchase boolean DEFAULT false,
    response_from_admin text,
    responded_at timestamp without time zone,
    travel_date date,
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: tours; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tours (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    main_image_url character varying(255),
    itinerary jsonb,
    is_active boolean DEFAULT true,
    duration_days integer,
    category character varying(100),
    destinations text[],
    slug character varying(255),
    themes text[],
    rating numeric(3,2) DEFAULT 4.8,
    review_count integer DEFAULT 0,
    is_new boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tours OWNER TO postgres;

--
-- Name: COLUMN tours.duration_days; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tours.duration_days IS 'Tour duration in days';


--
-- Name: COLUMN tours.destinations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tours.destinations IS 'Array of destination names for filtering';


--
-- Name: COLUMN tours.themes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tours.themes IS 'Array of tour themes (nature, culture, adventure, etc.)';


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'client'::character varying NOT NULL,
    is_verified boolean DEFAULT false,
    verification_token text,
    phone character varying(30),
    country character varying(100),
    creation_date timestamp with time zone DEFAULT now(),
    recent_activities jsonb,
    activity_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    last_login timestamp without time zone,
    profile_image_url text,
    preferences jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: COLUMN users.recent_activities; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.recent_activities IS 'JSON array of recent user activities';


--
-- Name: dashboard_overview; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.dashboard_overview AS
 SELECT ( SELECT count(*) AS count
           FROM public.users
          WHERE (COALESCE(users.is_active, true) = true)) AS active_users,
    ( SELECT count(*) AS count
           FROM public.bookings
          WHERE ((bookings.status)::text = 'Inquiry Pending'::text)) AS pending_inquiries,
    ( SELECT count(*) AS count
           FROM public.bookings
          WHERE ((bookings.status)::text = 'Payment Confirmed'::text)) AS confirmed_bookings,
    ( SELECT COALESCE(sum(bookings.total_price), (0)::numeric) AS "coalesce"
           FROM public.bookings
          WHERE ((bookings.status)::text = 'Payment Confirmed'::text)) AS total_revenue,
    ( SELECT count(*) AS count
           FROM public.tours
          WHERE (COALESCE(tours.is_active, true) = true)) AS active_tours,
    ( SELECT count(*) AS count
           FROM public.reviews
          WHERE (COALESCE(reviews.is_approved, false) = true)) AS approved_reviews,
    ( SELECT count(*) AS count
           FROM public.contact_inquiries
          WHERE ((contact_inquiries.status)::text = 'new'::text)) AS new_inquiries;


ALTER VIEW public.dashboard_overview OWNER TO postgres;

--
-- Name: gallery_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gallery_images (
    id uuid NOT NULL,
    title text NOT NULL,
    description text,
    location text,
    category text,
    date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    filename text NOT NULL,
    path text NOT NULL,
    views integer DEFAULT 0,
    thumbnail_path character varying(255),
    tags text[],
    is_featured boolean DEFAULT false,
    color_palette jsonb,
    aspect_ratio numeric(4,2),
    blur_hash text,
    file_size integer,
    dimensions jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.gallery_images OWNER TO postgres;

--
-- Name: COLUMN gallery_images.tags; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.gallery_images.tags IS 'Tags pour filtrage et recherche avancée';


--
-- Name: COLUMN gallery_images.is_featured; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.gallery_images.is_featured IS 'Images mises en avant dans la galerie';


--
-- Name: COLUMN gallery_images.color_palette; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.gallery_images.color_palette IS 'Palette de couleurs dominantes de l''image';


--
-- Name: COLUMN gallery_images.aspect_ratio; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.gallery_images.aspect_ratio IS 'Ratio largeur/hauteur pour layout masonry';


--
-- Name: COLUMN gallery_images.blur_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.gallery_images.blur_hash IS 'Hash pour placeholder pendant le chargement';


--
-- Name: COLUMN gallery_images.dimensions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.gallery_images.dimensions IS 'Dimensions réelles de l''image {width, height}';


--
-- Name: inclusions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inclusions (
    id integer NOT NULL,
    package_tier_id integer NOT NULL,
    description text NOT NULL,
    is_included boolean NOT NULL
);


ALTER TABLE public.inclusions OWNER TO postgres;

--
-- Name: inclusions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inclusions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inclusions_id_seq OWNER TO postgres;

--
-- Name: inclusions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inclusions_id_seq OWNED BY public.inclusions.id;


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    subject character varying(255),
    email_template text,
    sms_template text,
    push_template text,
    variables jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_templates OWNER TO postgres;

--
-- Name: TABLE notification_templates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.notification_templates IS 'Email and notification templates';


--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_templates_id_seq OWNER TO postgres;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    booking_id integer,
    type character varying(50) NOT NULL,
    channel character varying(20) DEFAULT 'email'::character varying NOT NULL,
    status character varying(20) NOT NULL,
    sent_at timestamp with time zone DEFAULT now(),
    template_id integer,
    priority character varying(20) DEFAULT 'medium'::character varying,
    scheduled_at timestamp without time zone,
    opened_at timestamp without time zone,
    clicked_at timestamp without time zone,
    metadata jsonb,
    title character varying(255),
    message text,
    is_read boolean DEFAULT false,
    CONSTRAINT notifications_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'urgent'::character varying])::text[])))
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: packagetiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packagetiers (
    id integer NOT NULL,
    tour_id integer NOT NULL,
    tier_name character varying(100) NOT NULL,
    price numeric(10,2) NOT NULL,
    hotel_type character varying(255),
    included_vehicle_id integer,
    inclusions_summary text[]
);


ALTER TABLE public.packagetiers OWNER TO postgres;

--
-- Name: packagetiers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packagetiers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.packagetiers_id_seq OWNER TO postgres;

--
-- Name: packagetiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packagetiers_id_seq OWNED BY public.packagetiers.id;


--
-- Name: passwordresets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passwordresets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    reset_token text,
    expires_at timestamp with time zone,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    email character varying(100) NOT NULL
);


ALTER TABLE public.passwordresets OWNER TO postgres;

--
-- Name: passwordresets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.passwordresets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.passwordresets_id_seq OWNER TO postgres;

--
-- Name: passwordresets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.passwordresets_id_seq OWNED BY public.passwordresets.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    booking_id integer NOT NULL,
    gateway_transaction_id character varying(255),
    amount numeric(12,2) NOT NULL,
    currency character varying(3) NOT NULL,
    status character varying(50) NOT NULL,
    payment_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: review_helpfulness; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_helpfulness (
    id integer NOT NULL,
    review_id integer,
    user_id integer,
    is_helpful boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.review_helpfulness OWNER TO postgres;

--
-- Name: TABLE review_helpfulness; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.review_helpfulness IS 'User votes on review helpfulness';


--
-- Name: review_helpfulness_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_helpfulness_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.review_helpfulness_id_seq OWNER TO postgres;

--
-- Name: review_helpfulness_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.review_helpfulness_id_seq OWNED BY public.review_helpfulness.id;


--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reviews_id_seq OWNER TO postgres;

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: security_logs; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.security_logs AS
 SELECT a.id,
    a.action AS event_type,
    concat(a.action, ' ', a.target_entity,
        CASE
            WHEN (a.entity_id IS NOT NULL) THEN concat(' #', a.entity_id)
            ELSE ''::text
        END) AS description,
    u.email AS user_email,
    u.role AS user_role,
    a."timestamp",
    a.ip_address,
    'Unknown'::text AS location,
    a.details,
    u.full_name AS admin_name
   FROM (public.audit_logs a
     LEFT JOIN public.users u ON ((a.admin_user_id = u.id)))
  ORDER BY a."timestamp" DESC;


ALTER VIEW public.security_logs OWNER TO postgres;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text,
    data_type character varying(20) DEFAULT 'string'::character varying,
    description text,
    is_public boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT system_settings_data_type_check CHECK (((data_type)::text = ANY ((ARRAY['string'::character varying, 'number'::character varying, 'boolean'::character varying, 'json'::character varying])::text[])))
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: TABLE system_settings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.system_settings IS 'System-wide configuration settings';


--
-- Name: COLUMN system_settings.is_public; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.system_settings.is_public IS 'Whether setting can be accessed by frontend';


--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tour_exclusions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tour_exclusions (
    id integer NOT NULL,
    tour_id integer,
    title character varying(255) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tour_exclusions OWNER TO postgres;

--
-- Name: TABLE tour_exclusions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tour_exclusions IS 'What is not included in tour packages';


--
-- Name: tour_exclusions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tour_exclusions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tour_exclusions_id_seq OWNER TO postgres;

--
-- Name: tour_exclusions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tour_exclusions_id_seq OWNED BY public.tour_exclusions.id;


--
-- Name: tour_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tour_images (
    id integer NOT NULL,
    tour_id integer,
    image_url text NOT NULL,
    caption text,
    is_primary boolean DEFAULT false,
    display_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tour_images OWNER TO postgres;

--
-- Name: TABLE tour_images; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tour_images IS 'Additional images for tours';


--
-- Name: tour_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tour_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tour_images_id_seq OWNER TO postgres;

--
-- Name: tour_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tour_images_id_seq OWNED BY public.tour_images.id;


--
-- Name: tour_inclusions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tour_inclusions (
    id integer NOT NULL,
    tour_id integer,
    inclusion_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    icon character varying(50),
    is_included boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tour_inclusions OWNER TO postgres;

--
-- Name: TABLE tour_inclusions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tour_inclusions IS 'What is included in tour packages';


--
-- Name: tour_inclusions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tour_inclusions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tour_inclusions_id_seq OWNER TO postgres;

--
-- Name: tour_inclusions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tour_inclusions_id_seq OWNED BY public.tour_inclusions.id;


--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_favorites (
    id integer NOT NULL,
    user_id integer,
    tour_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_favorites OWNER TO postgres;

--
-- Name: TABLE user_favorites; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_favorites IS 'User favorite tours';


--
-- Name: tour_statistics; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.tour_statistics AS
 SELECT t.id,
    t.name,
    COALESCE(t.rating, 4.8) AS rating,
    COALESCE(t.review_count, 0) AS review_count,
    count(b.id) AS total_bookings,
    count(
        CASE
            WHEN ((b.status)::text = 'Payment Confirmed'::text) THEN 1
            ELSE NULL::integer
        END) AS confirmed_bookings,
    avg(
        CASE
            WHEN (r.rating IS NOT NULL) THEN r.rating
            ELSE NULL::integer
        END) AS avg_review_rating,
    count(uf.id) AS favorite_count
   FROM (((public.tours t
     LEFT JOIN public.bookings b ON ((t.id = b.tour_id)))
     LEFT JOIN public.reviews r ON ((t.id = r.tour_id)))
     LEFT JOIN public.user_favorites uf ON ((t.id = uf.tour_id)))
  GROUP BY t.id, t.name, t.rating, t.review_count;


ALTER VIEW public.tour_statistics OWNER TO postgres;

--
-- Name: touraddons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.touraddons (
    tour_id integer NOT NULL,
    addon_id integer NOT NULL
);


ALTER TABLE public.touraddons OWNER TO postgres;

--
-- Name: tours_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tours_id_seq OWNER TO postgres;

--
-- Name: tours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tours_id_seq OWNED BY public.tours.id;


--
-- Name: user_activity_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.user_activity_summary AS
 SELECT u.id,
    u.full_name,
    u.email,
    COALESCE(u.is_active, true) AS is_active,
    u.last_login,
    count(b.id) AS total_bookings,
    count(r.id) AS total_reviews,
    count(uf.id) AS favorite_tours,
    COALESCE(u.activity_count, 0) AS activity_count
   FROM (((public.users u
     LEFT JOIN public.bookings b ON ((u.id = b.user_id)))
     LEFT JOIN public.reviews r ON ((u.id = r.user_id)))
     LEFT JOIN public.user_favorites uf ON ((u.id = uf.user_id)))
  GROUP BY u.id, u.full_name, u.email, u.is_active, u.last_login, u.activity_count;


ALTER VIEW public.user_activity_summary OWNER TO postgres;

--
-- Name: user_favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_favorites_id_seq OWNER TO postgres;

--
-- Name: user_favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_favorites_id_seq OWNED BY public.user_favorites.id;


--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_preferences (
    id integer NOT NULL,
    user_id integer,
    preference_key character varying(100) NOT NULL,
    preference_value text,
    data_type character varying(20) DEFAULT 'string'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT user_preferences_data_type_check CHECK (((data_type)::text = ANY ((ARRAY['string'::character varying, 'number'::character varying, 'boolean'::character varying, 'json'::character varying])::text[])))
);


ALTER TABLE public.user_preferences OWNER TO postgres;

--
-- Name: TABLE user_preferences; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_preferences IS 'User-specific preferences and settings';


--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_preferences_id_seq OWNER TO postgres;

--
-- Name: user_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_preferences_id_seq OWNED BY public.user_preferences.id;


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: utilisateurs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utilisateurs (
    id integer NOT NULL,
    username character varying(50) NOT NULL
);


ALTER TABLE public.utilisateurs OWNER TO postgres;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.utilisateurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.utilisateurs_id_seq OWNER TO postgres;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.utilisateurs_id_seq OWNED BY public.utilisateurs.id;


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    capacity integer NOT NULL,
    price_per_day numeric(10,2) NOT NULL
);


ALTER TABLE public.vehicles OWNER TO postgres;

--
-- Name: vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vehicles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicles_id_seq OWNER TO postgres;

--
-- Name: vehicles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vehicles_id_seq OWNED BY public.vehicles.id;


--
-- Name: addons id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addons ALTER COLUMN id SET DEFAULT nextval('public.addons_id_seq'::regclass);


--
-- Name: analytics_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events ALTER COLUMN id SET DEFAULT nextval('public.analytics_events_id_seq'::regclass);


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: auditlogs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditlogs ALTER COLUMN id SET DEFAULT nextval('public.auditlogs_id_seq'::regclass);


--
-- Name: blog_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_categories ALTER COLUMN id SET DEFAULT nextval('public.blog_categories_id_seq'::regclass);


--
-- Name: blog_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comments ALTER COLUMN id SET DEFAULT nextval('public.blog_comments_id_seq'::regclass);


--
-- Name: blog_posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_id_seq'::regclass);


--
-- Name: blog_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_tags ALTER COLUMN id SET DEFAULT nextval('public.blog_tags_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: contact_inquiries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_inquiries ALTER COLUMN id SET DEFAULT nextval('public.contact_inquiries_id_seq'::regclass);


--
-- Name: dashboard_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_metrics ALTER COLUMN id SET DEFAULT nextval('public.dashboard_metrics_id_seq'::regclass);


--
-- Name: inclusions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inclusions ALTER COLUMN id SET DEFAULT nextval('public.inclusions_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: packagetiers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packagetiers ALTER COLUMN id SET DEFAULT nextval('public.packagetiers_id_seq'::regclass);


--
-- Name: passwordresets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwordresets ALTER COLUMN id SET DEFAULT nextval('public.passwordresets_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: review_helpfulness id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpfulness ALTER COLUMN id SET DEFAULT nextval('public.review_helpfulness_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: tour_exclusions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_exclusions ALTER COLUMN id SET DEFAULT nextval('public.tour_exclusions_id_seq'::regclass);


--
-- Name: tour_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_images ALTER COLUMN id SET DEFAULT nextval('public.tour_images_id_seq'::regclass);


--
-- Name: tour_inclusions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_inclusions ALTER COLUMN id SET DEFAULT nextval('public.tour_inclusions_id_seq'::regclass);


--
-- Name: tours id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours ALTER COLUMN id SET DEFAULT nextval('public.tours_id_seq'::regclass);


--
-- Name: user_favorites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites ALTER COLUMN id SET DEFAULT nextval('public.user_favorites_id_seq'::regclass);


--
-- Name: user_preferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_preferences_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: utilisateurs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utilisateurs ALTER COLUMN id SET DEFAULT nextval('public.utilisateurs_id_seq'::regclass);


--
-- Name: vehicles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles ALTER COLUMN id SET DEFAULT nextval('public.vehicles_id_seq'::regclass);


--
-- Data for Name: addons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.addons (id, name, price, description) FROM stdin;
15	Extra Night Stay	5000.00	Extend your stay by one night.
16	Kochi Day Trip	4000.00	A full day guided tour of Kochi city.
14	Candlelight Dinner	3500.00	A romantic dinner for two.
\.


--
-- Data for Name: analytics_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_events (id, event_type, user_id, session_id, page_url, referrer, user_agent, ip_address, country, city, device_type, browser, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: article_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.article_categories (article_id, category_id) FROM stdin;
1	2
2	3
3	1
\.


--
-- Data for Name: article_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.article_tags (article_id, tag_id) FROM stdin;
1	1
2	2
2	4
3	1
3	3
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articles (id, title, slug, content, excerpt, main_image_url, author_id, status, created_at) FROM stdin;
1	10 Secret Spots in Kerala You Must Visit	10-secret-spots-kerala	Kerala is known for its backwaters, but there is so much more to discover. In this article, we take you off the beaten path to explore waterfalls, hidden beaches, and serene villages that most tourists miss. Prepare to be amazed by the untouched beauty of Kerala.	Go beyond the usual tourist trails and discover the hidden gems of 'God's Own Country'.	https://placehold.co/600x400/7045af/ffffff?text=Secret+Spots	1	published	2025-08-12 11:00:06.992268+01
2	A Food Lover's Guide to Tamil Nadu	food-guide-tamil-nadu	The cuisine of Tamil Nadu is a rich tapestry of flavors, spices, and history. This guide will walk you through the must-try dishes, from the fiery Chettinad chicken to the delicate flavors of a vegetarian thali. We will also share our favorite spots to eat like a local in Chennai and Madurai.	From Chettinad curries to Madurai's street food, embark on a delicious culinary journey.	https://placehold.co/600x400/59378a/ffffff?text=Food+Guide	1	published	2025-08-12 11:00:06.992268+01
3	Navigating South India Like a Local	navigating-south-india	Want to travel through South India with confidence? This article provides practical advice on everything from booking train tickets to navigating local buses and auto-rickshaws. We also share tips on how to find authentic local markets and cultural experiences.	Tips and tricks for using public transport and finding the best local experiences.	https://placehold.co/600x400/8b65c2/ffffff?text=Travel+Tips	1	published	2025-08-12 11:00:06.992268+01
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, admin_user_id, action, target_entity, entity_id, details, ip_address, user_agent, "timestamp") FROM stdin;
1	20	DELETE	User	22	{"email": "durelzanfack@gmail.com"}	\N	\N	2025-08-19 13:24:12.481143
2	20	UPDATE	User	23	{"role": "client", "email": "durelzanfack@gmail.com", "full_name": "Durel Zanfack", "is_active": false, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 13:53:02.64707
3	20	UPDATE	User	23	{"role": "client", "email": "durelzanfack@gmail.com", "full_name": "Durel Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 13:53:14.005193
4	20	TOGGLE_STATUS	User	23	{"new_status": false}	\N	\N	2025-08-19 13:56:30.064825
5	20	TOGGLE_STATUS	User	23	{"new_status": true}	\N	\N	2025-08-19 13:56:33.085003
6	20	UPDATE	User	21	{"role": "client", "email": "john.doe@email.com", "full_name": "John Doe", "is_active": false, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 14:11:42.416886
7	20	TOGGLE_STATUS	User	21	{"new_status": true}	\N	\N	2025-08-19 14:14:06.892879
8	20	UPDATE	User	20	{"role": "administrator", "email": "admin@savariking.com", "full_name": "Admin User", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 14:35:42.517699
9	20	UPDATE	User	21	{"role": "client", "email": "john.doe@email.com", "full_name": "John Doe", "is_active": false, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 14:35:50.399154
10	20	TOGGLE_STATUS	User	23	{"new_status": false}	\N	\N	2025-08-19 14:35:54.050514
11	20	TOGGLE_STATUS	User	21	{"new_status": true}	\N	\N	2025-08-19 14:35:57.307692
12	20	TOGGLE_STATUS	User	23	{"new_status": true}	\N	\N	2025-08-19 14:36:00.906795
13	20	CREATE	User	24	{"email": "vivienzanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 14:37:14.1934
14	20	CREATE	User	25	{"email": "natachazanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 14:52:58.279889
15	20	UPDATE	User	23	{"role": "client", "email": "durelzanfack@gmail.com", "full_name": "Durel Zanfack", "is_active": true, "is_verified": false}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 14:55:28.600638
16	20	TOGGLE_STATUS	User	24	{"new_status": false}	\N	\N	2025-08-19 14:56:01.342801
17	20	UPDATE	User	23	{"role": "client", "email": "durelzanfack@gmail.com", "full_name": "Durel Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:01:04.181499
18	20	UPDATE	User	24	{"role": "user", "email": "vivienzanfack@gmail.com", "full_name": "Vivien Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:01:13.339331
19	20	CREATE	User	26	{"email": "aureliezanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:06:04.526545
20	20	UPDATE	User	26	{"role": "administrator", "email": "aureliezanfack@gmail.com", "full_name": "Aurelie Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:06:23.791565
21	20	CREATE	User	27	{"email": "papazanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:12:02.029503
22	20	CREATE	User	28	{"email": "mamanzanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:15:30.068614
23	20	UPDATE	User	28	{"role": "administrator", "email": "mamanzanfack@gmail.com", "full_name": "Maman", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:15:43.467208
24	20	CREATE	User	29	{"email": "maman1zanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:16:23.431245
25	20	CREATE	User	30	{"email": "maman2zanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:16:48.055476
26	20	CREATE	User	31	{"email": "maman3zanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:17:05.824232
27	20	CREATE	User	32	{"email": "maman4zanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:17:28.103104
28	20	CREATE	User	33	{"email": "maman5zanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:18:03.931964
29	20	UPDATE	User	29	{"role": "client", "email": "maman1zanfack@gmail.com", "full_name": "Maman1", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:19:17.788367
30	20	UPDATE	User	30	{"role": "client", "email": "maman2zanfack@gmail.com", "full_name": "Maman2 Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:19:55.44481
31	20	UPDATE	User	31	{"role": "client", "email": "maman3zanfack@gmail.com", "full_name": "Maman3 Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:20:00.657087
32	20	UPDATE	User	32	{"role": "client", "email": "maman4zanfack@gmail.com", "full_name": "Maman4 Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:20:05.04734
33	20	UPDATE	User	33	{"role": "administrator", "email": "maman5zanfack@gmail.com", "full_name": "Maman5 Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:20:14.509223
34	20	UPDATE	User	34	{"role": "client", "email": "chicktype@gmail.com", "full_name": "David Junior", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:44:18.365877
35	20	CREATE	User	35	{"email": "johnzanfack@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:59:29.182023
36	20	UPDATE	User	35	{"role": "client", "email": "johnzanfack@gmail.com", "full_name": "John Johnson", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 15:59:49.377068
37	20	UPDATE	Vehicle	15	{"name": "5 Seater Sedan"}	\N	\N	2025-08-19 16:04:01.080742
38	20	UPDATE	Vehicle	15	{"name": "5 Seater Sedan"}	\N	\N	2025-08-19 16:04:07.549883
39	20	UPDATE	AddOn	14	{"name": "Candlelight Dinner"}	\N	\N	2025-08-19 16:04:17.063974
40	20	CREATE	Vehicle	18	{"name": "Big caisse"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 16:04:42.234041
41	20	UPDATE	User	32	{"role": "administrator", "email": "maman4zanfack@gmail.com", "full_name": "Maman4 Zanfack", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 16:09:03.237336
42	20	CREATE	User	36	{"email": "potofredo@gmail.com"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 16:57:06.534117
43	20	UPDATE	User	36	{"role": "client", "email": "potofredo@gmail.com", "full_name": "Mon Poto Le Fredo", "is_active": true, "is_verified": true}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-19 16:57:28.246723
44	20	DELETE	Vehicle	18	{"name": "Big caisse"}	\N	\N	2025-08-20 13:41:37.487398
45	20	TOGGLE_STATUS	Tour	11	{"new_status": false}	\N	\N	2025-08-20 13:59:39.730327
46	20	TOGGLE_STATUS	Tour	11	{"new_status": true}	\N	\N	2025-08-20 13:59:43.730314
47	20	CREATE	Tour	12	{"name": "New Tour - 2025-08-20T13:32:24.081Z"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-20 14:32:24.12497
48	20	TOGGLE_STATUS	Tour	12	{"new_status": true}	\N	\N	2025-08-20 14:45:11.806356
49	20	CREATE	Tour	13	{"name": "New Tour - 2025-08-20T13:45:14.539Z"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-20 14:45:14.572531
50	20	TOGGLE_STATUS	Tour	13	{"new_status": true}	\N	\N	2025-08-20 14:47:55.226569
51	20	DELETE	Tour	12	{"name": "New Tour - 2025-08-20T13:32:24.081Z"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-20 14:48:08.209565
52	20	DELETE	Tour	13	{"name": "New Tour - 2025-08-20T13:45:14.539Z"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-20 14:58:58.609603
53	20	CREATE	Tour	14	{"name": "Test Tour"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-20 14:59:29.418893
54	20	TOGGLE_STATUS	Tour	14	{"new_status": true}	\N	\N	2025-08-20 14:59:35.333008
55	20	CREATE	Tour	15	{"name": "Tour Test"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-20 15:22:40.645888
56	20	DELETE	Tour	14	{"name": "Test Tour"}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-20 15:24:24.973418
57	20	DELETE	User	36	{"email": "potofredo@gmail.com"}	\N	\N	2025-08-20 15:53:04.183167
\.


--
-- Data for Name: auditlogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auditlogs (id, admin_user_id, action_type, target_entity, target_id, details, "timestamp") FROM stdin;
\.


--
-- Data for Name: blog_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_categories (id, name, slug, description, created_at) FROM stdin;
1	Travel Tips	travel-tips	Helpful tips and advice for travelers	2025-08-12 07:02:51.544856
2	Destinations	destinations	Information about various travel destinations	2025-08-12 07:02:51.544856
3	Culture	culture	Cultural insights and experiences	2025-08-12 07:02:51.544856
4	Food & Cuisine	food-cuisine	Local food and culinary experiences	2025-08-12 07:02:51.544856
\.


--
-- Data for Name: blog_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_comments (id, article_id, user_id, parent_comment_id, content, is_approved, created_at) FROM stdin;
\.


--
-- Data for Name: blog_post_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_post_categories (blog_post_id, category_id) FROM stdin;
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_posts (id, title, slug, content, excerpt, featured_image_url, author_id, status, tags, meta_title, meta_description, read_time, view_count, is_featured, published_at, created_at, updated_at) FROM stdin;
1	The 10 Hidden Treasures of Kerala	the-10-hidden-treasures-of-kerala	Kerala, nicknamed "God's Own Country", is famous for its backwaters and beaches. But beyond the beaten path lie unknown gems. In this article, we take you on a discovery of secret waterfalls, authentic spice villages, and ancient temples.	Explore Kerala like never before with our guide to its secret destinations.	https://placehold.co/1200x600/27AE60/FFFFFF/png?text=Kerala	20	published	{kerala,"south india",travel,nature,"off the beaten path"}	Top 10 Hidden Treasures of Kerala | Ebenezer Tours	A complete guide to the 10 secret places to discover in Kerala for an unforgettable trip.	8	1450	t	2025-08-16 10:47:22.304088	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
2	A Culinary Journey into the Heart of Tamil Nadu	a-culinary-journey-into-the-heart-of-tamil-nadu	The cuisine of Tamil Nadu is a symphony of spices and flavors. From the spicy Chettinad to the crispy dosa, each dish tells a story. Join us for an overview of the culinary specialties that will awaken your taste buds and enrich your journey.	Discover the authentic flavors of Tamil Nadu, from rich curries to vegetarian delights.	https://placehold.co/1200x600/E67E22/FFFFFF/png?text=Tamil+Nadu+Cuisine	28	published	{cuisine,"tamil nadu","south india",gastronomy}	Culinary Guide to Tamil Nadu | Ebenezer Tours	Discover the must-try dishes during your custom journey in Tamil Nadu.	6	920	f	2025-08-11 10:47:22.304088	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
3	Preparing Your Trip: The Essentials for South India	preparing-your-trip-the-essentials-for-south-india	A trip to South India is a transformative experience, and good preparation is the key to success. What clothes to pack for the tropical climate? What are the visa formalities? Follow our complete guide to forget nothing and leave with peace of mind.	The ultimate checklist for a successful trip to South India: clothing, health, and local tips.	https://placehold.co/1200x600/3498DB/FFFFFF/png?text=Trip+Preparation	20	published	{tips,"south india",preparation,"practical guide"}	Essential Checklist for South India | Ebenezer Tours	Our practical advice to properly pack your suitcase and prepare for your trip to South India.	5	2300	t	2025-08-06 10:47:22.304088	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
4	The Secret Beaches of the Malabar Coast	the-secret-beaches-of-the-malabar-coast	Forget the crowded beaches! The Malabar Coast, stretching along Kerala, is home to golden sand coves and pristine wild beaches of breathtaking beauty. We reveal our favorite corners of paradise for a relaxing holiday.	Escape to idyllic and preserved beaches, far from the crowds.	https://placehold.co/1200x600/8E44AD/FFFFFF/png?text=Malabar+Beaches	28	published	{beach,kerala,"south india",relaxation}	The Most Beautiful Secret Beaches of the Malabar Coast | Ebenezer Tours	Discover our selection of the most beautiful hidden beaches for your stay in Kerala.	7	1100	f	2025-08-01 10:47:22.304088	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
5	Trekking in the Western Ghats: A Beginner's Guide	trekking-in-the-western-ghats-a-beginners-guide	The Western Ghats offer lush landscapes, endless tea plantations, and trails for all levels. If you are a beginner, this guide is for you. We cover the equipment, choosing routes in Munnar, and safety tips.	Everything you need to know to start trekking in the mountains of Kerala.	https://placehold.co/1200x600/16A085/FFFFFF/png?text=Munnar+Trekking	20	published	{trekking,"western ghats",munnar,adventure}	Beginner's Trekking Guide to Kerala | Ebenezer Tours	Our tips to prepare for your first hike in the beautiful landscapes of Munnar.	9	1650	f	2025-07-21 10:47:22.304088	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
6	Pondicherry: The French Heritage in the Heart of India	pondicherry-the-french-heritage-in-the-heart-of-india	Pondicherry is a city of fascinating contrasts. Its cobblestone streets, colonial architecture, and seaside promenade give it a unique charm. This article guides you through the French Quarter and the cultural heritage of this one-of-a-kind city.	An itinerary to explore the best of Pondicherry, between French culture and Indian spirituality.	https://placehold.co/1200x600/F1C40F/FFFFFF/png?text=Pondicherry	28	published	{pondicherry,"tamil nadu",culture,history}	Exploring Pondicherry: A Guide to its French Heritage | Ebenezer Tours	Discover Pondicherry with our complete guide for a unique cultural immersion.	8	1350	f	2025-07-12 10:47:22.304088	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
7	Solo Travel in South India: Tips and Tricks	solo-travel-in-south-india-tips-and-tricks	Traveling alone in South India is an incredibly enriching adventure. It is a welcoming and safe region. We have gathered our best tips for planning your itinerary, getting around easily, and fully enjoying your freedom.	The essential guide for a successful and serene solo trip in Kerala and Tamil Nadu.	https://placehold.co/1200x600/E74C3C/FFFFFF/png?text=Solo+Travel	20	published	{"solo travel",safety,tips,"south india"}	Essential Tips for Solo Travel in South India | Ebenezer Tours	Travel solo with confidence thanks to our practical tips and safety advice.	6	1950	f	2025-06-21 10:47:22.304088	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
8	The Majestic Temples of Tamil Nadu: An Architectural Guide	the-majestic-temples-of-tamil-nadu-an-architectural-guide	Tamil Nadu is the land of temples. From Madurai to Thanjavur, Dravidian architecture reaches heights of complexity and beauty. This article is being written to introduce you to the most beautiful temples and their history. (CONTENT TO BE FINALIZED)	An overview of the architectural masterpieces not to be missed on your trip.	https://placehold.co/1200x600/95A5A6/FFFFFF/png?text=Indian+Temples	28	draft	{temples,architecture,history,"tamil nadu"}	Architectural Guide to the Temples of Tamil Nadu | Ebenezer Tours	Explore the finest examples of Dravidian architecture in southern India.	10	0	f	\N	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
9	Kerala Festivals: The 2024 Guide	kerala-festivals-the-2024-guide	This article presented the calendar of Kerala's festivals for the year 2024. It is now archived. A new version for 2025 will be published soon. Festivals like Thrissur Pooram are unforgettable cultural experiences.	An overview of the colorful and vibrant celebrations of Kerala in 2024.	https://placehold.co/1200x600/7F8C8D/FFFFFF/png?text=Festivals+2024	20	archived	{festivals,kerala,culture,tradition}	Guide to Kerala Festivals 2024 | Ebenezer Tours	The calendar and description of the main cultural festivals of Kerala for 2024.	7	4200	f	2024-01-10 11:00:00	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
10	The Magic of Kerala's Backwaters by Houseboat	the-magic-of-keralas-backwaters-by-houseboat	Cruising the backwaters on a traditional houseboat is the quintessential Kerala experience. Discover local life along the canals, savor freshly prepared cuisine on board, and let yourself be lulled by the tranquility of the surroundings. Here is everything you need to know to plan this magical getaway.	The complete guide for an unforgettable experience on the backwaters of Kerala.	https://placehold.co/1200x600/2980B9/FFFFFF/png?text=Kerala+Backwaters	28	published	{backwaters,kerala,houseboat,nature,relaxation}	Complete Guide to a Houseboat Cruise in Kerala | Ebenezer Tours	Plan your dream stay on the backwaters of Kerala with our expert advice.	7	2800	f	2025-05-21 10:47:22.304088	2025-08-21 10:47:22.304088	2025-08-21 10:47:22.304088
\.


--
-- Data for Name: blog_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_tags (id, name, slug, created_at) FROM stdin;
1	Kerala	kerala	2025-08-21 10:14:40.780617+01
2	Tamil Nadu	tamil-nadu	2025-08-21 10:14:40.780617+01
3	Safety	safety	2025-08-21 10:14:40.780617+01
4	Food	food	2025-08-21 10:14:40.780617+01
5	Temples	temples	2025-08-21 10:14:40.780617+01
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookings (id, user_id, tour_id, package_tier_id, travel_date, number_of_persons, additional_vehicles, selected_addons, status, payment_timestamp, total_price, selected_currency, inquiry_date, customer_notes, admin_notes, cancellation_reason, cancelled_at, confirmed_at) FROM stdin;
15	21	10	21	2025-12-20	2	\N	\N	Payment Confirmed	\N	23000.00	INR	2025-08-11 15:08:36.615937+01	\N	\N	\N	\N	\N
\.


--
-- Data for Name: contact_inquiries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_inquiries (id, name, email, phone, subject, message, inquiry_type, status, priority, assigned_to, response_sent, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dashboard_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_metrics (id, metric_name, metric_value, metric_date, period_type, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: gallery_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gallery_images (id, title, description, location, category, date, filename, path, views, thumbnail_path, tags, is_featured, color_palette, aspect_ratio, blur_hash, file_size, dimensions, created_at, updated_at) FROM stdin;
bb82ec1b-a306-40ee-8f78-fbfe2412f8df	Titre 1	Description de l'image a fournir ici	Inde	ville	2025-08-10 00:00:00	d8a3af1e-fa6c-4d54-b499-538f64bbe882.jpg	C:/Users/Administrator/Desktop/Sam/Booking Website/ebooking-app/backend/uploads/gallery/d8a3af1e-fa6c-4d54-b499-538f64bbe882.jpg	0	C:/Users/Administrator/Desktop/Sam/Booking Website/ebooking-app/backend/uploads/gallery/thumbnails/d8a3af1e-fa6c-4d54-b499-538f64bbe882_thumb.jpg	{urbain,culture,architecture}	f	\N	1.50	\N	\N	\N	2025-08-11 12:16:07.028461	2025-08-11 12:16:07.028461
\.


--
-- Data for Name: inclusions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inclusions (id, package_tier_id, description, is_included) FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_templates (id, name, subject, email_template, sms_template, push_template, variables, is_active, created_at, updated_at) FROM stdin;
1	booking_confirmation	Booking Confirmation - {{tour_name}}	Dear {{user_name}}, your booking for {{tour_name}} has been confirmed. Booking ID: {{booking_id}}	\N	\N	{"tour_name": "string", "user_name": "string", "booking_id": "string"}	t	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
2	booking_inquiry	New Booking Inquiry Received	Thank you for your interest in {{tour_name}}. We will contact you within 24 hours.	\N	\N	{"tour_name": "string", "user_name": "string"}	t	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
3	password_reset	Password Reset Request	Click the link to reset your password: {{reset_link}}	\N	\N	{"user_name": "string", "reset_link": "string"}	t	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, booking_id, type, channel, status, sent_at, template_id, priority, scheduled_at, opened_at, clicked_at, metadata, title, message, is_read) FROM stdin;
24	21	15	payment_confirmed	email	sent	2025-08-11 15:08:36.656458+01	\N	medium	\N	\N	\N	\N	Payment Confirmed	Your payment has been successfully processed. Get ready for your adventure!	f
25	22	\N	account_registered	email	done	2025-08-12 10:41:45.867977+01	\N	medium	\N	\N	\N	\N	Welcome to Ebenezer Tours!	Welcome! Your account has been created successfully.	f
26	23	\N	account_registered	email	done	2025-08-19 13:50:04.580738+01	\N	medium	\N	\N	\N	\N	Welcome to Ebenezer Tours!	Welcome! Your account has been created successfully.	f
27	34	\N	account_registered	email	done	2025-08-19 15:43:44.128592+01	\N	medium	\N	\N	\N	\N	Welcome to Ebenezer Tours!	Welcome! Your account has been created successfully.	f
\.


--
-- Data for Name: packagetiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.packagetiers (id, tour_id, tier_name, price, hotel_type, included_vehicle_id, inclusions_summary) FROM stdin;
20	10	Super Prime	30000.00	Luxury (4-5 Star)	16	{"Luxury Hotel","1 Lunch"}
21	10	Prime	23000.00	3 Star Hotels	15	{"3 Star Hotel","1 Lunch"}
22	10	Mini Prime	17000.00	Budget-friendly stay	15	{"Budget Stay","1 Lunch"}
23	11	Luxury Cruise	45000.00	Premium Houseboat	16	{"Premium Houseboat","All Meals Included"}
\.


--
-- Data for Name: passwordresets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passwordresets (id, user_id, reset_token, expires_at, status, email) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, booking_id, gateway_transaction_id, amount, currency, status, payment_date) FROM stdin;
3	15	pi_sample_transaction_id	23000.00	INR	succeeded	2025-08-11 15:08:36.624934+01
\.


--
-- Data for Name: review_helpfulness; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_helpfulness (id, review_id, user_id, is_helpful, created_at) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, user_id, tour_id, rating, review_text, is_approved, submission_date, helpful_count, images, verified_purchase, response_from_admin, responded_at, travel_date) FROM stdin;
3	21	10	5	An absolutely amazing experience! The team at Ebenezer Tours was fantastic. Highly recommended!	t	2025-08-11 15:08:36.643138+01	0	\N	f	\N	\N	\N
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, setting_key, setting_value, data_type, description, is_public, created_at, updated_at) FROM stdin;
1	site_name	Ebenezer Tours	string	Website name	t	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
2	contact_email	info@ebenezertours.com	string	Main contact email	t	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
3	contact_phone	+91-9876543210	string	Main contact phone	t	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
4	booking_advance_days	5	number	Minimum days in advance for booking	f	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
5	max_file_size_mb	10	number	Maximum file upload size in MB	f	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
6	currency_symbol	₹	string	Default currency symbol	t	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
7	timezone	Asia/Kolkata	string	Default timezone	f	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
\.


--
-- Data for Name: tour_exclusions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tour_exclusions (id, tour_id, title, description, created_at) FROM stdin;
\.


--
-- Data for Name: tour_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tour_images (id, tour_id, image_url, caption, is_primary, display_order, created_at) FROM stdin;
\.


--
-- Data for Name: tour_inclusions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tour_inclusions (id, tour_id, inclusion_type, title, description, icon, is_included, created_at) FROM stdin;
\.


--
-- Data for Name: touraddons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.touraddons (tour_id, addon_id) FROM stdin;
10	14
10	15
11	16
\.


--
-- Data for Name: tours; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tours (id, name, main_image_url, itinerary, is_active, duration_days, category, destinations, slug, themes, rating, review_count, is_new, created_at, updated_at) FROM stdin;
10	Explore South India's Coastal Beauty	https://images.unsplash.com/photo-1528181304800-259b08848526?q=80&w=2070&auto=format&fit=crop	[{"day": 1, "title": "Pickup at Trivandrum Airport & Kanyakumari Sightseeing"}, {"day": 2, "title": "Trivandrum, Kovalam & Poovar"}, {"day": 3, "title": "Drop to Trivandrum Airport"}]	t	3	\N	{Kerala,"Tamil Nadu",Karnataka}	\N	{nature,culture,relaxation}	4.80	120	f	2025-08-12 07:02:51.544856	2025-08-12 07:02:51.544856
11	Cochin Backwater Serenity	https://images.unsplash.com/photo-1624555130581-39392c519fff?q=80&w=2070&auto=format&fit=crop	[{"day": 1, "title": "Arrival in Cochin & Fort Kochi Exploration"}, {"day": 2, "title": "Houseboat Cruise in Alleppey Backwaters"}, {"day": 3, "title": "Departure from Cochin"}]	t	3	\N	{Kerala,"Tamil Nadu",Karnataka}	\N	{nature,culture,relaxation}	4.80	120	f	2025-08-12 07:02:51.544856	2025-08-20 13:59:43.69922
15	Tour Test		{}	t	0		{}	New Slug	{}	0.00	0	t	2025-08-20 15:22:40.638238	2025-08-20 15:22:40.638238
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_favorites (id, user_id, tour_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_preferences (id, user_id, preference_key, preference_value, data_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, full_name, email, password, role, is_verified, verification_token, phone, country, creation_date, recent_activities, activity_count, is_active, last_login, profile_image_url, preferences, updated_at) FROM stdin;
32	Maman4 Zanfack	maman4zanfack@gmail.com	$2a$10$1nnD5spupa4fQTs3BKQQPe/qEN94sZRtfNs2LrXmUT9z6WmeNaybi	administrator	t	\N	\N	\N	2025-08-19 15:17:28.071723+01	\N	0	t	\N	\N	\N	2025-08-19 16:09:03.203294+01
21	John Doe	john.doe@email.com	$2a$10$ckO3xKAUODm2oRCRKsDRveUq0STAbBgjQ9Lv5MLHFgIzHvIL7/gym	client	t	\N	\N	\N	2025-08-11 15:08:36.494634+01	\N	0	t	\N	\N	\N	2025-08-19 14:35:57.306387+01
25	Natacha Zanfack	natachazanfack@gmail.com	$2a$10$uMIhpLEZ34ydG21YskhaR.FAe6bUivMgVa2iUYDFyfTtiXy2Ugavy	client	t	\N	\N	\N	2025-08-19 14:52:58.277178+01	\N	0	t	\N	\N	\N	2025-08-19 14:52:58.277178+01
23	Durel Zanfack	durelzanfack@gmail.com	$2a$10$Yo19QTAeiDFXaawaoHfuL.IXDf149O1W/zlaf8EiuF1xhNlY2hcFy	client	t	b516214d0262a94476314afe472ef09b0f863153c5bf958291067c3d018253ae	\N	\N	2025-08-19 13:50:04.550502+01	\N	0	t	\N	\N	\N	2025-08-19 15:01:04.147932+01
24	Vivien Zanfack	vivienzanfack@gmail.com	$2a$10$boYDDV31IHMD4hXh0uhNn.L8.xZqImpMStZa6nsGJG9JsWmr/SDgG	user	t	\N	\N	\N	2025-08-19 14:37:14.16128+01	\N	0	t	\N	\N	\N	2025-08-19 15:01:13.308182+01
26	Aurelie Zanfack	aureliezanfack@gmail.com	$2a$10$S/k1wn6U4C1ipz9uc7adXeT5qb2sWvk2C0bfJhgDQxKX0L2QULBWW	administrator	t	\N	\N	\N	2025-08-19 15:06:04.519459+01	\N	0	t	\N	\N	\N	2025-08-19 15:06:23.758514+01
27	Papa Zanfack	papazanfack@gmail.com	$2a$10$aKmUAiUyJaDz1ilSxsLQe.yfVA1IWG5/Xg5aO3.S106TvlVo1etQG	administrator	t	\N	\N	\N	2025-08-19 15:12:01.997656+01	\N	0	t	\N	\N	\N	2025-08-19 15:12:01.997656+01
28	Maman	mamanzanfack@gmail.com	$2a$10$2UnDQk1ulfs9g73kwa.hj.2CnonPWw8Pv6V6ajk8Kx93/3dY5qqnm	administrator	t	\N	\N	\N	2025-08-19 15:15:30.036424+01	\N	0	t	\N	\N	\N	2025-08-19 15:15:43.43246+01
29	Maman1	maman1zanfack@gmail.com	$2a$10$f70diojfqkQgV9aEFhexYuQDWhHPfbbSStEyfxYDnfghbl5F7tcbe	client	t	\N	\N	\N	2025-08-19 15:16:23.399633+01	\N	0	t	\N	\N	\N	2025-08-19 15:19:17.754395+01
30	Maman2 Zanfack	maman2zanfack@gmail.com	$2a$10$HpEMoU2eCQDQaNKi647oVurk3tbmQ9e3yu5zJhjI7mXuL99JAw1E2	client	t	\N	\N	\N	2025-08-19 15:16:48.053566+01	\N	0	t	\N	\N	\N	2025-08-19 15:19:55.410536+01
31	Maman3 Zanfack	maman3zanfack@gmail.com	$2a$10$dZQDE.2SG5P/6DiFWo18d.MltTvlvKpJHZnxvboyq3BbW2I2gWlC.	client	t	\N	\N	\N	2025-08-19 15:17:05.792833+01	\N	0	t	\N	\N	\N	2025-08-19 15:20:00.626023+01
33	Maman5 Zanfack	maman5zanfack@gmail.com	$2a$10$OCmuM2tt4APMSlY39n4eNObHGbfTZ.jgvs3sXlshF7C7Tjq/firWG	administrator	t	\N	\N	\N	2025-08-19 15:18:03.900203+01	\N	0	t	\N	\N	\N	2025-08-19 15:20:14.478635+01
34	David Junior	chicktype@gmail.com	$2a$10$dVN04pPLXRe7D2qgVObk0O9zb.ZiEHhXN/njVG2bZ.eGjoJTpIewu	client	t	d5ea6116e1979b601addddd25abe59e30224f8bd741a47f66f70d71bb898effa	\N	\N	2025-08-19 15:43:44.084536+01	[{"type": "Account Created", "details": {}, "timestamp": "2025-08-19T14:43:44.116Z"}]	1	t	\N	\N	\N	2025-08-19 15:44:18.35971+01
35	John Johnson	johnzanfack@gmail.com	$2a$10$JRZUHXeXihZCidGCDnnQpeua9di.sYpi.PqOE7CZ7nw1lPw08MU4m	client	t	\N	\N	\N	2025-08-19 15:59:29.150167+01	\N	0	t	\N	\N	\N	2025-08-19 15:59:49.34267+01
20	Admin User	admin@savariking.com	$2a$10$ckO3xKAUODm2oRCRKsDRveokmDKoTZLWtc5JsrMY01s79HaAFWf5K	administrator	t	\N	\N	\N	2025-08-11 15:08:36.494634+01	[{"type": "Logged In", "details": {}, "timestamp": "2025-08-21T07:42:49.986Z"}, {"type": "Logged In", "details": {}, "timestamp": "2025-08-20T05:50:42.399Z"}, {"type": "Logged In", "details": {}, "timestamp": "2025-08-19T16:28:42.116Z"}, {"type": "Logged In", "details": {}, "timestamp": "2025-08-19T16:20:35.550Z"}, {"type": "Logged In", "details": {}, "timestamp": "2025-08-19T16:17:57.818Z"}]	6	t	\N	\N	\N	2025-08-21 08:42:49.990371+01
\.


--
-- Data for Name: utilisateurs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utilisateurs (id, username) FROM stdin;
1	admin
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehicles (id, name, capacity, price_per_day) FROM stdin;
16	7 Seater SUV	6	5000.00
17	12 Seater Tempo Traveller	11	7000.00
15	5 Seater Sedan	7	4000.00
\.


--
-- Name: addons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.addons_id_seq', 16, true);


--
-- Name: analytics_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_events_id_seq', 1, false);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articles_id_seq', 3, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 57, true);


--
-- Name: auditlogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auditlogs_id_seq', 9, true);


--
-- Name: blog_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_categories_id_seq', 19, true);


--
-- Name: blog_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_comments_id_seq', 2, true);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_posts_id_seq', 10, true);


--
-- Name: blog_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_tags_id_seq', 5, true);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookings_id_seq', 15, true);


--
-- Name: contact_inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_inquiries_id_seq', 1, false);


--
-- Name: dashboard_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dashboard_metrics_id_seq', 1, false);


--
-- Name: inclusions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inclusions_id_seq', 1, false);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 14, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 27, true);


--
-- Name: packagetiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packagetiers_id_seq', 23, true);


--
-- Name: passwordresets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.passwordresets_id_seq', 3, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 3, true);


--
-- Name: review_helpfulness_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_helpfulness_id_seq', 1, false);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reviews_id_seq', 3, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 33, true);


--
-- Name: tour_exclusions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tour_exclusions_id_seq', 1, false);


--
-- Name: tour_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tour_images_id_seq', 1, false);


--
-- Name: tour_inclusions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tour_inclusions_id_seq', 1, false);


--
-- Name: tours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tours_id_seq', 15, true);


--
-- Name: user_favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_favorites_id_seq', 1, false);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_preferences_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 36, true);


--
-- Name: utilisateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.utilisateurs_id_seq', 1, false);


--
-- Name: vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vehicles_id_seq', 18, true);


--
-- Name: addons addons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addons
    ADD CONSTRAINT addons_pkey PRIMARY KEY (id);


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id);


--
-- Name: article_categories article_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.article_categories
    ADD CONSTRAINT article_categories_pkey PRIMARY KEY (article_id, category_id);


--
-- Name: article_tags article_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.article_tags
    ADD CONSTRAINT article_tags_pkey PRIMARY KEY (article_id, tag_id);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_slug_key UNIQUE (slug);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auditlogs auditlogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditlogs
    ADD CONSTRAINT auditlogs_pkey PRIMARY KEY (id);


--
-- Name: blog_categories blog_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_categories blog_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_slug_key UNIQUE (slug);


--
-- Name: blog_comments blog_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_pkey PRIMARY KEY (id);


--
-- Name: blog_post_categories blog_post_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_post_categories
    ADD CONSTRAINT blog_post_categories_pkey PRIMARY KEY (blog_post_id, category_id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_slug_key UNIQUE (slug);


--
-- Name: blog_tags blog_tags_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_tags
    ADD CONSTRAINT blog_tags_name_key UNIQUE (name);


--
-- Name: blog_tags blog_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_tags
    ADD CONSTRAINT blog_tags_pkey PRIMARY KEY (id);


--
-- Name: blog_tags blog_tags_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_tags
    ADD CONSTRAINT blog_tags_slug_key UNIQUE (slug);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: contact_inquiries contact_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_inquiries
    ADD CONSTRAINT contact_inquiries_pkey PRIMARY KEY (id);


--
-- Name: dashboard_metrics dashboard_metrics_metric_name_metric_date_period_type_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_metric_name_metric_date_period_type_key UNIQUE (metric_name, metric_date, period_type);


--
-- Name: dashboard_metrics dashboard_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_pkey PRIMARY KEY (id);


--
-- Name: gallery_images gallery_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery_images
    ADD CONSTRAINT gallery_images_pkey PRIMARY KEY (id);


--
-- Name: inclusions inclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inclusions
    ADD CONSTRAINT inclusions_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_name_key UNIQUE (name);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: packagetiers packagetiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packagetiers
    ADD CONSTRAINT packagetiers_pkey PRIMARY KEY (id);


--
-- Name: passwordresets passwordresets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwordresets
    ADD CONSTRAINT passwordresets_pkey PRIMARY KEY (id);


--
-- Name: payments payments_booking_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_booking_id_key UNIQUE (booking_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: review_helpfulness review_helpfulness_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpfulness
    ADD CONSTRAINT review_helpfulness_pkey PRIMARY KEY (id);


--
-- Name: review_helpfulness review_helpfulness_review_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpfulness
    ADD CONSTRAINT review_helpfulness_review_id_user_id_key UNIQUE (review_id, user_id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: tour_exclusions tour_exclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_exclusions
    ADD CONSTRAINT tour_exclusions_pkey PRIMARY KEY (id);


--
-- Name: tour_images tour_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_images
    ADD CONSTRAINT tour_images_pkey PRIMARY KEY (id);


--
-- Name: tour_inclusions tour_inclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_inclusions
    ADD CONSTRAINT tour_inclusions_pkey PRIMARY KEY (id);


--
-- Name: touraddons touraddons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.touraddons
    ADD CONSTRAINT touraddons_pkey PRIMARY KEY (tour_id, addon_id);


--
-- Name: tours tours_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_pkey PRIMARY KEY (id);


--
-- Name: tours tours_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_slug_key UNIQUE (slug);


--
-- Name: user_favorites user_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_favorites user_favorites_user_id_tour_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_tour_id_key UNIQUE (user_id, tour_id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_user_id_preference_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_preference_key_key UNIQUE (user_id, preference_key);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: utilisateurs utilisateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: idx_analytics_events_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_date ON public.analytics_events USING btree (created_at DESC);


--
-- Name: idx_analytics_events_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_session ON public.analytics_events USING btree (session_id);


--
-- Name: idx_analytics_events_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_type ON public.analytics_events USING btree (event_type);


--
-- Name: idx_analytics_events_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_user ON public.analytics_events USING btree (user_id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_admin_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_admin_user ON public.audit_logs USING btree (admin_user_id);


--
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_entity ON public.audit_logs USING btree (target_entity, entity_id);


--
-- Name: idx_audit_logs_ip; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_ip ON public.audit_logs USING btree (ip_address);


--
-- Name: idx_audit_logs_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_timestamp ON public.audit_logs USING btree ("timestamp" DESC);


--
-- Name: idx_blog_posts_author; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_blog_posts_author ON public.blog_posts USING btree (author_id);


--
-- Name: idx_blog_posts_featured; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_blog_posts_featured ON public.blog_posts USING btree (is_featured);


--
-- Name: idx_blog_posts_published; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_blog_posts_published ON public.blog_posts USING btree (published_at DESC);


--
-- Name: idx_blog_posts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_blog_posts_status ON public.blog_posts USING btree (status);


--
-- Name: idx_blog_posts_tags; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_blog_posts_tags ON public.blog_posts USING gin (tags);


--
-- Name: idx_blog_posts_view_count; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_blog_posts_view_count ON public.blog_posts USING btree (view_count DESC);


--
-- Name: idx_bookings_cancelled_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bookings_cancelled_at ON public.bookings USING btree (cancelled_at);


--
-- Name: idx_bookings_confirmed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bookings_confirmed_at ON public.bookings USING btree (confirmed_at);


--
-- Name: idx_bookings_inquiry_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bookings_inquiry_date ON public.bookings USING btree (inquiry_date DESC);


--
-- Name: idx_contact_inquiries_assigned; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_contact_inquiries_assigned ON public.contact_inquiries USING btree (assigned_to);


--
-- Name: idx_contact_inquiries_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_contact_inquiries_date ON public.contact_inquiries USING btree (created_at DESC);


--
-- Name: idx_contact_inquiries_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_contact_inquiries_priority ON public.contact_inquiries USING btree (priority);


--
-- Name: idx_contact_inquiries_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_contact_inquiries_status ON public.contact_inquiries USING btree (status);


--
-- Name: idx_contact_inquiries_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_contact_inquiries_type ON public.contact_inquiries USING btree (inquiry_type);


--
-- Name: idx_dashboard_metrics_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dashboard_metrics_date ON public.dashboard_metrics USING btree (metric_date DESC);


--
-- Name: idx_dashboard_metrics_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dashboard_metrics_name ON public.dashboard_metrics USING btree (metric_name);


--
-- Name: idx_dashboard_metrics_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dashboard_metrics_period ON public.dashboard_metrics USING btree (period_type);


--
-- Name: idx_gallery_aspect_ratio; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gallery_aspect_ratio ON public.gallery_images USING btree (aspect_ratio);


--
-- Name: idx_gallery_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gallery_category ON public.gallery_images USING btree (category);


--
-- Name: idx_gallery_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gallery_created_at ON public.gallery_images USING btree (created_at);


--
-- Name: idx_gallery_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gallery_date ON public.gallery_images USING btree (date);


--
-- Name: idx_gallery_featured; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gallery_featured ON public.gallery_images USING btree (is_featured);


--
-- Name: idx_gallery_tags; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gallery_tags ON public.gallery_images USING gin (tags);


--
-- Name: idx_gallery_views; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gallery_views ON public.gallery_images USING btree (views);


--
-- Name: idx_notifications_channel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_channel ON public.notifications USING btree (channel);


--
-- Name: idx_notifications_is_read; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_is_read ON public.notifications USING btree (is_read);


--
-- Name: idx_notifications_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_priority ON public.notifications USING btree (priority);


--
-- Name: idx_notifications_scheduled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_scheduled ON public.notifications USING btree (scheduled_at);


--
-- Name: idx_notifications_sent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_sent ON public.notifications USING btree (sent_at);


--
-- Name: idx_notifications_template; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_template ON public.notifications USING btree (template_id);


--
-- Name: idx_notifications_user_sent_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_user_sent_at ON public.notifications USING btree (user_id, sent_at DESC);


--
-- Name: idx_reviews_helpful_count; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_helpful_count ON public.reviews USING btree (helpful_count DESC);


--
-- Name: idx_reviews_travel_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_travel_date ON public.reviews USING btree (travel_date);


--
-- Name: idx_reviews_verified_purchase; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_verified_purchase ON public.reviews USING btree (verified_purchase);


--
-- Name: idx_system_settings_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_settings_key ON public.system_settings USING btree (setting_key);


--
-- Name: idx_system_settings_public; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_settings_public ON public.system_settings USING btree (is_public);


--
-- Name: idx_tour_exclusions_tour; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tour_exclusions_tour ON public.tour_exclusions USING btree (tour_id);


--
-- Name: idx_tour_images_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tour_images_order ON public.tour_images USING btree (display_order);


--
-- Name: idx_tour_images_primary; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tour_images_primary ON public.tour_images USING btree (is_primary);


--
-- Name: idx_tour_images_tour; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tour_images_tour ON public.tour_images USING btree (tour_id);


--
-- Name: idx_tour_inclusions_tour; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tour_inclusions_tour ON public.tour_inclusions USING btree (tour_id);


--
-- Name: idx_tour_inclusions_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tour_inclusions_type ON public.tour_inclusions USING btree (inclusion_type);


--
-- Name: idx_tours_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tours_created_at ON public.tours USING btree (created_at DESC);


--
-- Name: idx_tours_destinations; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tours_destinations ON public.tours USING gin (destinations);


--
-- Name: idx_tours_duration; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tours_duration ON public.tours USING btree (duration_days);


--
-- Name: idx_tours_is_new; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tours_is_new ON public.tours USING btree (is_new);


--
-- Name: idx_tours_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tours_rating ON public.tours USING btree (rating DESC);


--
-- Name: idx_tours_themes; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tours_themes ON public.tours USING gin (themes);


--
-- Name: idx_user_favorites_tour; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_favorites_tour ON public.user_favorites USING btree (tour_id);


--
-- Name: idx_user_favorites_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_favorites_user ON public.user_favorites USING btree (user_id);


--
-- Name: idx_user_preferences_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_preferences_key ON public.user_preferences USING btree (preference_key);


--
-- Name: idx_user_preferences_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_preferences_user ON public.user_preferences USING btree (user_id);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_last_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_last_login ON public.users USING btree (last_login DESC);


--
-- Name: gallery_images gallery_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER gallery_updated_at_trigger BEFORE UPDATE ON public.gallery_images FOR EACH ROW EXECUTE FUNCTION public.update_gallery_updated_at();


--
-- Name: blog_posts update_blog_posts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_blog_posts_updated_at BEFORE UPDATE ON public.blog_posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: contact_inquiries update_contact_inquiries_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_contact_inquiries_updated_at BEFORE UPDATE ON public.contact_inquiries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notification_templates update_notification_templates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_notification_templates_updated_at BEFORE UPDATE ON public.notification_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: system_settings update_system_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON public.system_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tours update_tours_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_tours_updated_at BEFORE UPDATE ON public.tours FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_preferences update_user_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_preferences_updated_at BEFORE UPDATE ON public.user_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: analytics_events analytics_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: article_categories article_categories_article_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.article_categories
    ADD CONSTRAINT article_categories_article_id_fkey FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: article_categories article_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.article_categories
    ADD CONSTRAINT article_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.blog_categories(id) ON DELETE CASCADE;


--
-- Name: article_tags article_tags_article_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.article_tags
    ADD CONSTRAINT article_tags_article_id_fkey FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: article_tags article_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.article_tags
    ADD CONSTRAINT article_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.blog_tags(id) ON DELETE CASCADE;


--
-- Name: articles articles_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.utilisateurs(id);


--
-- Name: audit_logs audit_logs_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: auditlogs auditlogs_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditlogs
    ADD CONSTRAINT auditlogs_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.users(id);


--
-- Name: blog_comments blog_comments_article_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_article_id_fkey FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: blog_comments blog_comments_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES public.blog_comments(id) ON DELETE CASCADE;


--
-- Name: blog_comments blog_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: blog_post_categories blog_post_categories_blog_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_post_categories
    ADD CONSTRAINT blog_post_categories_blog_post_id_fkey FOREIGN KEY (blog_post_id) REFERENCES public.blog_posts(id) ON DELETE CASCADE;


--
-- Name: blog_post_categories blog_post_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_post_categories
    ADD CONSTRAINT blog_post_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.blog_categories(id) ON DELETE CASCADE;


--
-- Name: blog_posts blog_posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: bookings bookings_package_tier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_package_tier_id_fkey FOREIGN KEY (package_tier_id) REFERENCES public.packagetiers(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: contact_inquiries contact_inquiries_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_inquiries
    ADD CONSTRAINT contact_inquiries_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: notifications fk_notifications_template; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_notifications_template FOREIGN KEY (template_id) REFERENCES public.notification_templates(id);


--
-- Name: inclusions inclusions_package_tier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inclusions
    ADD CONSTRAINT inclusions_package_tier_id_fkey FOREIGN KEY (package_tier_id) REFERENCES public.packagetiers(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: packagetiers packagetiers_included_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packagetiers
    ADD CONSTRAINT packagetiers_included_vehicle_id_fkey FOREIGN KEY (included_vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: packagetiers packagetiers_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packagetiers
    ADD CONSTRAINT packagetiers_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: payments payments_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: review_helpfulness review_helpfulness_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpfulness
    ADD CONSTRAINT review_helpfulness_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.reviews(id) ON DELETE CASCADE;


--
-- Name: review_helpfulness review_helpfulness_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpfulness
    ADD CONSTRAINT review_helpfulness_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tour_exclusions tour_exclusions_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_exclusions
    ADD CONSTRAINT tour_exclusions_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tour_images tour_images_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_images
    ADD CONSTRAINT tour_images_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tour_inclusions tour_inclusions_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tour_inclusions
    ADD CONSTRAINT tour_inclusions_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: touraddons touraddons_addon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.touraddons
    ADD CONSTRAINT touraddons_addon_id_fkey FOREIGN KEY (addon_id) REFERENCES public.addons(id) ON DELETE CASCADE;


--
-- Name: touraddons touraddons_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.touraddons
    ADD CONSTRAINT touraddons_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

